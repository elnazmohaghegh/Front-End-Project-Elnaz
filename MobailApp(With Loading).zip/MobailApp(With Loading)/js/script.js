////////    Loading Site :  /////////////////
window.addEventListener('load', function(){
    const loader = document.querySelector('.loader');
    loader.classList += ' hidden';
})

////////    Button Up :    ///////////////////
const toTop = document.querySelector('.to-top');

window.addEventListener('scroll',function(){
    if(window.pageYOffset > 400){
        toTop.classList.add('active');
    }else{
        toTop.classList.remove('active');
    }
})

////////    Filter Menu : ////////////////

const indicatorr = document.querySelector('.indicatorry').children;
const maini = document.querySelector('.container').children;


for(let i=0; i<indicatorr.length;i++){
    indicatorr[i].onclick = function(){
        for(let x=0 ; x < indicatorr.length; x++){
            indicatorr[x].classList.remove('active');
        }
        this.classList.add('active');
        const displayItem = this.getAttribute('data-filter');
        for(let z =0; z<maini.length;z++){
            maini[z].style.transform = 'scale(0)';
            setTimeout(()=>{
                maini[z].style.display = 'none';
            },500)

            if(maini[z].getAttribute('data-category') == displayItem || displayItem == 'all'){
                maini[z].style.transform = 'scale(1)';
                setTimeout(()=>{
                    maini[z].style.display = 'flex';
                },500)
            }
        }
    }
}

//**********Stop play Video***********//

// Get all <video> elements.
const videos = document.querySelectorAll('video');

// Pause all <video> elements except for the one that started playing.
function pauseOtherVideos({ target }) {
  for (const video of videos) {
    if (video !== target) {
      video.pause();
    }
  }
}

// Listen for the 'play' event on all the <video> elements.
for (const video of videos) {
  video.addEventListener('play', pauseOtherVideos);
}



//////////  LANguages Site :   //////////////


// Heaader and Main(Section) languages  :
var languages ={
    fa:{
        hone : "صفحه اصلی",
        htwo : "درباره ما",
        hthree : "خدمات آموزشی",
        hfour : " خدمات گردشگری",
        hfive : "خدمات بانکی",
        hsix : "خدمات سرمایه گذاری",
        hseven : "خدمات پزشکی",
        heeight : "ارتباط با ما",
        select : "انتخاب زبان",
        HoneOnvan : "مجموعه ویدئوهای آموزشی خرید با کارت گردشگری ",
        HTowone : "ویدئوهای تبلیغاتی",
        SPone : "تبلیغات",
        SHfour : "ویدئو اول",
        SHfourr : "ویدئو دوم",
        SHfourrr : "ویدئو سوم",
        SHfourrrr : "ویدئو چهارم"


    },
    en:{
        hone : "Main Page",
        htwo : "About us",
        hthree : "Educational services",
        hfour : "Tourism services",
        hfive : "Banking services",
        hsix : "Investment services",
        hseven : "Medical services",
        heeight : "Contact us",
        select : "select languages",
        HoneOnvan : "A collection of educational videos for shopping with a tourist card",
        HTowone  : "Promotional videos",
        SPone : "Advertising",
        SHfour : "First video",
        SHfourr : "The second video",
        SHfourrr : "The third video",
        SHfourrrr : "The fourth video",
        SccHTowOnvan : "Bank card training videos and financial services",
        SccPtwo : "Bank card and financial services",
        ScccHTowOnvan : "Educational videos of tourism services",
        ScccPThree : "tourism services",
        SccccHTowOnvan : "Investment service videos",
        SccccPFour : "Investment services",
        ScccccHTowOnvan : "Videos of Cart services",
        ScccccPFive: "Cart services",

        AllMenu : "All",
        TabliqMenu : "Advertise",
        MaliiMenu : "Financial",
        ToristMenu : "Tourism",
        SarmayeMenu : "Investment",
        PezeshkMenu : "Application",
        SecHTowoneNew : "Card training videos",
        SecpNeww : "Cart"
        
    },
    ar:{
        hone : "الصفحة الرئيسية",
        htwo : "معلومات عنا",
        hthree : "خدمات تعليمية",
        hfour : "خدمات السياحة",
        hfive : "خدمات بنكية",
        hsix : "خدمات الاستثمار",
        hseven : "الخدمات الطبية",
        heeight : "اتصل بنا",
        select : "اختيار اللغة",
        HoneOnvan : "مجموعة من الفيديوهات التعليمية للتسوق ببطاقة سياحية",
        HTowone : "فيديوهات ترويجية",
        SPone : "دعاية",
        SHfour : "أول مقطع",
        SHfourr : "الفيديو الثاني",
        SHfourrr : "الفيديو الثالث",
        SHfourrrr : "الفيديو الرابع",
        SccHTowOnvan : "فيديوهات تدريب البطاقة المصرفية والخدمات المالية",
        SccPtwo : "البطاقة المصرفية والخدمات المالية",
        ScccHTowOnvan : "فيديوهات تعليمية للخدمات السياحية",
        ScccPThree : "خدمات السياحة",
        SccccHTowOnvan : "فيديوهات خدمة الاستثمار",
        SccccPFour : "خدمات الاستثمار",
        ScccccHTowOnvan : "فيديوهات للخدمات تطبیق",
        ScccccPFive: "الخدمات تطبيق",
        
        AllMenu : "الجميع",
        TabliqMenu : "الإعلان",
        MaliiMenu : "الأمور المالية",
        ToristMenu : "السياحة",
        SarmayeMenu : "استثمار",
        PezeshkMenu : "تطبيق",
        
        SecHTowoneNew : "فيديوهات تدريب البطاقة",
        SecpNeww : "بطاقة"
    }
}


if(window.location.hash){
    if(window.location.hash === "#en"){
 

        // onvan va title section one : //
        // secHoneOnvan.textContent = languages.en.HoneOnvan;
        secHTowone.textContent = languages.en.HTowone;
        secpone.textContent = languages.en.SPone;
        //video avaal//
        sechfour.textContent = languages.en.SHfour;
        sechfouur.textContent = languages.en.SHfour;
        sechfoour.textContent = languages.en.SHfour;
        sechffour.textContent = languages.en.SHfour;
        sechhfour.textContent = languages.en.SHfour;
        //video dovvom//
        sechfourr.textContent = languages.en.SHfourr;
        sechfouurr.textContent = languages.en.SHfourr;
        sechfoourr.textContent = languages.en.SHfourr;
        sechffourr.textContent = languages.en.SHfourr;
        sechhfourr.textContent = languages.en.SHfourr;
        //video sevvom//
        sechfourrr.textContent = languages.en.SHfourrr;
        sechfouurrr.textContent = languages.en.SHfourrr;
        sechfoourrr.textContent = languages.en.SHfourrr;
        sechffourrr.textContent = languages.en.SHfourrr;
        sechhfourrr.textContent = languages.en.SHfourrr;
        //video chaharom//
        sechfourrrr.textContent = languages.en.SHfourrrr;
        sechfouurrrr.textContent = languages.en.SHfourrrr;
        sechfooourrrr.textContent = languages.en.SHfourrrr;
        sechffourrrr.textContent = languages.en.SHfourrrr;
        sechhfourrrr.textContent = languages.en.SHfourrrr;
        // onvan va title section Two : //
        seccHTowtwo.textContent = languages.en.SccHTowOnvan;
        seccptwo.textContent = languages.en.SccPtwo;
        // onvan va title section Three : //
        secccHTowthree.textContent = languages.en.ScccHTowOnvan;
        secccpthree.textContent = languages.en.ScccPThree;
        // onvan va titlee section four : //
        seccccHTowfour.textContent = languages.en.SccccHTowOnvan;
        seccccpfour.textContent = languages.en.SccccPFour;
        // onvan va titlee section five : //
        secccccHTowfive.textContent = languages.en.ScccccHTowOnvan;
        secccccpfive.textContent = languages.en.ScccccPFive;
        // Menu :
        alll.textContent = languages.en.AllMenu;
        tabliq.textContent = languages.en.TabliqMenu;
        malii.textContent = languages.en.MaliiMenu;
        torist.textContent = languages.en.ToristMenu;
        sarmaye.textContent = languages.en.SarmayeMenu;
        pezeshk.textContent = languages.en.PezeshkMenu;
        secHTnew.textContent = languages.en.SecHTowoneNew;
        secpneww.textContent = languages.en.SecpNeww;
     
        
     
        

        document.body.style.direction = "ltr";

    }
}
if(window.location.hash){
    if(window.location.hash === "#ar"){
     

        // onvan va title section one : //
        // secHoneOnvan.textContent = languages.ar.HoneOnvan;
        secHTowone.textContent = languages.ar.HTowone;
        secpone.textContent = languages.ar.SPone;
        //video avaal//
        sechfour.textContent = languages.ar.SHfour;
        sechfouur.textContent = languages.ar.SHfour;
        sechfoour.textContent = languages.ar.SHfour;
        sechffour.textContent = languages.ar.SHfour;
        sechhfour.textContent = languages.ar.SHfour;
        //video dovvom//
        sechfourr.textContent = languages.ar.SHfourr;
        sechfouurr.textContent = languages.ar.SHfourr;
        sechfoourr.textContent = languages.ar.SHfourr;
        sechffourr.textContent = languages.ar.SHfourr;
        sechhfourr.textContent = languages.ar.SHfourr;
        //video sevvom//
        sechfourrr.textContent = languages.ar.SHfourrr;
        sechfouurrr.textContent = languages.ar.SHfourrr;
        sechfoourrr.textContent = languages.ar.SHfourrr;
        sechffourrr.textContent = languages.ar.SHfourrr;
        sechhfourrr.textContent = languages.ar.SHfourrr;
        //video chaharom//
        sechfourrrr.textContent = languages.ar.SHfourrrr;
        sechfouurrrr.textContent = languages.ar.SHfourrrr;
        sechfooourrrr.textContent = languages.ar.SHfourrrr;
        sechffourrrr.textContent = languages.ar.SHfourrrr;
        sechhfourrrr.textContent = languages.ar.SHfourrrr;
        // onvan va title section Two : //
        seccHTowtwo.textContent = languages.ar.SccHTowOnvan;
        seccptwo.textContent = languages.ar.SccPtwo;
        // onvan va title section Three : //
        secccHTowthree.textContent = languages.ar.ScccHTowOnvan;
        secccpthree.textContent = languages.ar.ScccPThree;
        // onvan va titlee section four : //
        seccccHTowfour.textContent = languages.ar.SccccHTowOnvan;
        seccccpfour.textContent = languages.ar.SccccPFour;
        // onvan va titlee section five : //
        secccccHTowfive.textContent = languages.ar.ScccccHTowOnvan;
        secccccpfive.textContent = languages.ar.ScccccPFive;
        // Menu :
        alll.textContent = languages.ar.AllMenu;
        tabliq.textContent = languages.ar.TabliqMenu;
        malii.textContent = languages.ar.MaliiMenu;
        torist.textContent = languages.ar.ToristMenu;
        sarmaye.textContent = languages.ar.SarmayeMenu;
        pezeshk.textContent = languages.ar.PezeshkMenu;
        secHTnew.textContent = languages.ar.SecHTowoneNew;
        secpneww.textContent = languages.ar.SecpNeww;



        document.body.style.direction = "rtl";

    }
}

var reload = document.querySelectorAll('.reload');

for( i=0 ; i<= reload.length ; i++){
    reload[i].onclick = function(){
        window.location.hash = this.getAttribute('href');
        window.location.reload();
    }

}
